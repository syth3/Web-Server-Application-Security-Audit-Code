#!/bin/bash

sudo apt-get install apache2 -y
sudo apt-get install libapache2-mod-php -y
