<?php
    setcookie("token", "", time()-60);
    echo "You have been successfully logged out"
?>