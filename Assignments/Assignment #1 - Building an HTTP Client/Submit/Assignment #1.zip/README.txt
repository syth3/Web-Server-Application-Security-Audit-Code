Dependencies, compilers/interpreters, and development environments that are necessary to run my code
 - There is only one dependency for my code, Python 3.x must be installed. Other than Python, there are no additional dependencies to download. This code was tested on Python 3.8.1

How to run my code
 - Simply run the following command from the command line:
    python3 HTTPClient.py URL
 - Example:
    python3 HTTPClient.py https://www.facebook.com

Note: 
 - In Windows, you may need to substitute "python3" for "python" in the terminal command
 - Please include the http(s) portion of the url