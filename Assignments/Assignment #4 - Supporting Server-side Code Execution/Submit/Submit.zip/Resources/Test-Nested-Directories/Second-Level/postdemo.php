<?php
	echo "POST Output\n";
	echo $_POST['first'] . " " . $_POST['last'];
?>
