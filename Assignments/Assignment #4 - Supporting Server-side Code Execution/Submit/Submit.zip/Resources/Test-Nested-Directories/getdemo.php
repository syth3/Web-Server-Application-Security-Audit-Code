<?php
	echo "GET Output\n";
	echo $_GET['first'] . " " . $_GET['last'];
?>
